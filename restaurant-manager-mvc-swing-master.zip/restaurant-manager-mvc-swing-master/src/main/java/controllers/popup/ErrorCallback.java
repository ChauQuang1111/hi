package controllers.popup;

/**
 * createAt Dec 31, 2020
 *
 * @author Đỗ Tuấn Anh <daclip26@gmail.com>
 */
public interface ErrorCallback {

    public abstract void onError(Exception e);
}
