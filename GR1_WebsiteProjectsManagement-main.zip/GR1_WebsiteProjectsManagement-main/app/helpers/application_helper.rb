module ApplicationHelper
	def verbose_date(date)
		date.strftime('%B %d %Y')
	end
end
